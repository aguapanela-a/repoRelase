from setuptools import setup, find_packages

setup(
    name="miRepoRelases",                          
    version="0.1.0",                               
    packages=find_packages(),                      
    description="Un paquete pip simple de saludo", 
    author="Erick Buitrago",                       
    author_email="ericksbp23@gmail.com",           
    url="https://github.com/aguapanela-a/repoRelase",    
)